package com.boa.inventoryapi;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "inventoryapi"; // BPMN Process ID

}
