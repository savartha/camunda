package com.boa.loanprocess.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.loanprocess.models.Appointment;
import com.boa.loanprocess.repositories.AppointmentRepo;

@Service
public class AppointmentService {
    @Autowired
	private AppointmentRepo appointmentRepo;
    
    
    public Appointment saveAppointment(Appointment appointment) {
    	return appointmentRepo.save(appointment);
    }
}
