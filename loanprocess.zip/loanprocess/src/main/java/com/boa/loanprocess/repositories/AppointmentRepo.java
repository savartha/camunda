package com.boa.loanprocess.repositories;



import org.springframework.data.jpa.repository.JpaRepository;

import com.boa.loanprocess.models.Appointment;

public interface AppointmentRepo extends JpaRepository<Appointment,Long>{

}