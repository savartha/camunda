package com.boa.loanprocess;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "loanprocess"; // BPMN Process ID

}
