package com.boa.messagedemo;

public class ProcessConstants {

  public static final String PROCESS_DEFINITION_KEY = "messagedemo"; // BPMN Process ID

}
